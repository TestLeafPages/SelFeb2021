package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setFileName() {
		excelFileName = "Credentials";

	}
	
	@Test(dataProvider="fetchData")
	public void loginLogout(String username,String password){
			
		new LoginPage()
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickLogout();

	}

}
