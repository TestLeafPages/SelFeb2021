package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class LoginPage extends ProjectSpecificMethods {

	@Given("Enter username as {string}")
	public LoginPage enterUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
		return this;
	}

	@Given("Enter password as {string}")
	public LoginPage enterPassword(String password) {

		driver.findElement(By.id("password")).sendKeys(password);
		return this;
	}

	@When("Click on the login button")
	public HomePage clickLoginButton() {

		driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
		return new HomePage();
	}

	public LoginPage clickLoginForNegativeData() {

		driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
		return this;

	}

	@But("The Error should be displayed")
	public LoginPage verifyErrorMessage() {
		System.out.println("Error message is displayed");
		return this;
	}

}
