package testcase;

import base.ProjectSpecificMethods;
import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;

@CucumberOptions(features="src/main/java/features/Login.feature", 
					glue="page", 
					monochrome=true
					//dryRun = true,
					//snippets= SnippetType.CAMELCASE
					)

public class CucumberRunner extends ProjectSpecificMethods{

}
