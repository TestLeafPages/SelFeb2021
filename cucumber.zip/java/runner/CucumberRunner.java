package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features= {"src/test/java/features"},
				 glue = "steps", 
				 monochrome=true , 
				 publish = true,
				// tags= "@smoke" //to execute only smoke scenarios
				// tags = "@regression or @functional" //execute all the test cases having either regression or functional
				//tags = "@regression and @functional" // to execute test scenarios having both function and regression
				tags = "@file" //to execute all the test cases except smoke
				)
public class CucumberRunner extends AbstractTestNGCucumberTests{

}
