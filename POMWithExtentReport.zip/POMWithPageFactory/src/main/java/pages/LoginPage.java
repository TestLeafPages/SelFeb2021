package pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
		
	}

	// actionElementName
	public LoginPage enterUsername(String username) throws IOException {
		try {
			driver.findElement(By.id("username")).sendKeys(username);
			reportStep(username+" Username is enetered successfully","pass");
		} catch (Exception e) {
			reportStep(username+" Username is not enetered successfully","fail");
		}
		return this;
	}

	public LoginPage enterPassword(String password) throws IOException {
		try {
			driver.findElement(By.id("password")).sendKeys(password);
			reportStep(password+" password is enetered successfully","pass");
		} catch (Exception e) {
			reportStep(password+" password is not enetered successfully","fail");
		}
		return this;
	}

	public HomePage clickLoginButton() throws IOException {
		try {
			driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
			reportStep("Login button is clicked successfully","pass");
		} catch (Exception e) {
			reportStep("Login button is not clicked successfully","fail");
		}
		return new HomePage(driver, node);
	}

	public LoginPage clickLoginForNegativeData() {
		driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
		return this;

	}

	public LoginPage verifyErrorMessage() {
		System.out.println("Error message is displayed");
		return this;
	}

}
