package testcase;

import java.io.IOException;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods {
	
	@Test
	public void runCreateLead() throws IOException  {
		new LoginPage(driver, node)
		.enterUsername("DemoCSR")
		.enterPassword("crmsfa")
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsLink();

	}

}
