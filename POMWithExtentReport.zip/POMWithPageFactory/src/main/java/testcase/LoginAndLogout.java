package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setTestDetails() {
		excelFileName = "Credentials";
		testName = "LoginAndLogout";
		testDescription = "Login with positive data";
		testAuthor = "Hari";
		testCategory = "Smoke";

	}
	
	@Test(dataProvider="fetchData")
	public void loginLogout(String username,String password) throws IOException{
			
		new LoginPage(driver, node)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton();
		

	}

}
