package base;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import cucumber.api.testng.AbstractTestNGCucumberTests;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;

public class ProjectSpecificMethods extends AbstractTestNGCucumberTests{
	
	private static final ThreadLocal<RemoteWebDriver> remoteWebDriver = new ThreadLocal<RemoteWebDriver>();
	
	public void setDriver() {
		remoteWebDriver.set(new ChromeDriver());
	}
	
	public  RemoteWebDriver getDriver() {
		return remoteWebDriver.get();
	}
	
	
	
	
//	public static ChromeDriver driver;
	public String excelFileName;
	
	@BeforeMethod
	public void startApp() {
		WebDriverManager.chromedriver().setup();
		setDriver();
		//driver = new ChromeDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] methodForData() throws IOException {
		ReadExcel re = new ReadExcel();
		return re.excelRead(excelFileName);
			
	}
	
}
