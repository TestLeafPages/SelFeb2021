package pages;

import org.junit.Assert;
import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import cucumber.api.java.en.Then;

public class HomePage extends ProjectSpecificMethods {
	

	public LoginPage clickLogout() {

		getDriver().findElement(By.className("decorativeSubmit")).click();

		return new LoginPage();
	}

	public MyHomePage clickCrmsfaLink() {

		getDriver().findElement(By.linkText("CRM/SFA")).click();

		return new MyHomePage();

	}
	
	@Then("The Homepage should be displayed")
	public void verifyHomePage() {
		boolean displayed = getDriver().findElement(By.linkText("CRM/SFA")).isDisplayed();
		Assert.assertTrue(displayed);

	}

}
