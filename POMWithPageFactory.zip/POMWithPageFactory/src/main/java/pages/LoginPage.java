package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}
	
	
	  @CacheLookup
	  
	  @FindBy(how=How.XPATH, using="//input[@class='inputLogin']") List<WebElement> eleUsername;
	 
	
	/*
	 * //AND condition
	 * 
	 * @FindBys( {
	 * 
	 * @FindBy(how=How.ID, using="username123"),
	 * 
	 * @FindBy(how=How.XPATH, using="//input[@name='USERNAME']") } ) WebElement
	 * eleUsername;
	 */
		
		//OR condition
	/*
	 * @FindAll( {
	 * 
	 * @FindBy(how=How.ID, using="username123"),
	 * 
	 * @FindBy(how=How.XPATH, using="//input[@name='USERNAME']") } ) WebElement
	 * eleUsername;
	 */
	

	@CacheLookup
	@FindBy(how=How.ID, using="password") 
	WebElement elePassword;
	
	//actionElementName
	public LoginPage enterUsername(String username) {
		eleUsername.get(0).sendKeys(username);
		//eleUsername.sendKeys(username);
		//driver.findElement(By.id("username")).sendKeys(username);
		return this;
	}
	
	public LoginPage enterPassword(String password) {
		elePassword.sendKeys(password);
	//	driver.findElement(By.id("password")).sendKeys(password);
		return this;
	}
	
	@CacheLookup
	@FindBy(how=How.XPATH, using="//input[@class='decorativeSubmit']") 
	WebElement eleLogin;
	
	public HomePage clickLoginButton() {
		eleLogin.click();
	//	driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
		return new HomePage();
	}
	
	
	public LoginPage clickLoginForNegativeData() {
		eleLogin.click();
		//driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
		return this;

	}
	
	public LoginPage verifyErrorMessage() {
		System.out.println("Error message is displayed");
		return this;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
